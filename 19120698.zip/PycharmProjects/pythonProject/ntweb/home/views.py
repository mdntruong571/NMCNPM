from django.shortcuts import render

# Create your views here.

from django.http import HttpResponse

def index(request):
    myname = 'Nguyen Truong'
    return render(request, 'home/index.html', {'name': myname})

def mssv(request):
    return HttpResponse('<h1>19120698<h1>')